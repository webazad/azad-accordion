<?php
// silence is golden.